import{j as e,c as t,R as n}from"./chunk-18074b33.js";const s=()=>e.jsx("main",{});t.createRoot(document.getElementById("app")).render(e.jsx(n.StrictMode,{children:e.jsx(s,{})}));
